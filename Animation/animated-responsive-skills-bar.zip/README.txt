A Pen created at CodePen.io. You can find this one at http://codepen.io/iPawan/pen/PwomxJ.

 The Responsive Skills bar gives you an opportunity to show visitors to your site how qualified you. Add a skill title, percentage of proficiency, and a color (hex value). It’s a quick and colorful way to showcase your knowledge about you.