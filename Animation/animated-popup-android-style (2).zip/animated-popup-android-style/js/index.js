$('a').on('click', function(){
  $('.wrap, a').toggleClass('active');
  
  return false;
});