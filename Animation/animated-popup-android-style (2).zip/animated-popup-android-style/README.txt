A Pen created at CodePen.io. You can find this one at http://codepen.io/ashwinsaxena/pen/ByMVZJ.

 An android style animated popup information box.