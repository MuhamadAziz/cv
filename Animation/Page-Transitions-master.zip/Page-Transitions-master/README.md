Page-Transitions
================

A little bit of CSS &amp; JS to animate page transitions

See it in action [HERE](http://rusty.am/playground/css-page-transitions/index.html).
