A Pen created at CodePen.io. You can find this one at http://codepen.io/brycesnyder/pen/meedEN.

 Using only CSS creating a slide out menu with animations with pseudo siblings and checkbox. Also works with mobile.