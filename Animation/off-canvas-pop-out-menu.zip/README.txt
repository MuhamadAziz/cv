A Pen created at CodePen.io. You can find this one at http://codepen.io/keefyboooo/pen/eNZogZ.

 Bare bones pattern for a pop up menu, using CSS transitions and a bit of jQuery to toggle classes

The toggle is coming from the element behind the burger menu so there isnt any dead space in-between the lines.

I am still playing around with this so if you have any suggestions/improvements please let me know