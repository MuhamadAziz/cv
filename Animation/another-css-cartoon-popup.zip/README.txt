A Pen created at CodePen.io. You can find this one at http://codepen.io/webinnov_france/pen/zxWjaj.

 Another css cartoon popup using svg (small arrow) ! Enjoy it !