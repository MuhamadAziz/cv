A Pen created at CodePen.io. You can find this one at http://codepen.io/arjunamgain/pen/nAuer.

 Html and css progress bar