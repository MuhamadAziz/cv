module NiceScroll
  module Rails
    VERSION = "3.5.4.1"
  end
end