A Pen created at CodePen.io. You can find this one at http://codepen.io/Tushkiz/pen/lntvd.

 Skills bar using HTML5 progress tag