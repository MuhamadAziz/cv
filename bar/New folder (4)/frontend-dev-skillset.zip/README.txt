A Pen created at CodePen.io. You can find this one at http://codepen.io/cfleschhut/pen/Kfdpw.

 Prototype for the skills section of my personal website

Built with the awesome charts.js
http://www.chartjs.org/