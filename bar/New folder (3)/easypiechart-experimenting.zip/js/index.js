$(function() {
  $('.chart').easyPieChart({
    scaleColor: false,
    lineWidth: 10,
    lineCap: 'round',
    barColor: '#333',
    size: 150,
    animate: 500
  });
});