A Pen created at CodePen.io. You can find this one at http://codepen.io/16-Bit-Bacon/pen/gayPbv.

 A little example of how you could display your experience in web development.